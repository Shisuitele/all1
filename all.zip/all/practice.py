def ss(L1):
    for i in range(len(L1)-1):
        mv = min(L1[i:])
        mi= L1.index(mv,i)

        L1[i],L1[mi] = L1[mi],L1[i]

    return L1

print(ss([10,2,7,4,1,0]))